from django.shortcuts import render
from api.models import VKIDProvider

def index_view(request):
    return render(request, "base.html")

def form_view(request, hash_link):
    try:
        vkid_obj = VKIDProvider.objects.get(hash_link=hash_link)
        if vkid_obj.active == False:
            return render(request, "core/inactive.html")
        else:
            return render(request, "core/form.html", {"vkid_obj":vkid_obj,})
    except Exception as e:
        return render(request, "core/not_found.html")
