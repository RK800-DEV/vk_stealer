from django.urls import path
from . import views

urlpatterns = [
    path('', views.index_view),
    path('<str:hash_link>/', views.form_view),
]