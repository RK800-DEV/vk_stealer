from django.db import models


class AccountData(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    ip_address = models.CharField(max_length=100)
    id_vk = models.IntegerField()
    password = models.CharField(max_length=512)

    def __str__(self):
        return self.ip_address

class VKIDProvider(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    id_vk = models.IntegerField()
    hash_link = models.CharField(max_length=4, unique=True)
    active = models.BooleanField(default=True)

    def __str__(self):
        return str(self.id_vk)