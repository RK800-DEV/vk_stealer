from django.urls import path
from .views import save_credentials

urlpatterns = [
    path('save/', save_credentials),
]