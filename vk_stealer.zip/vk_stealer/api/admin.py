from django.contrib import admin
from .models import VKIDProvider, AccountData

class VKIDProviderAdmin(admin.ModelAdmin):
    list_display = ['created_at', 'id_vk', 'hash_link', 'active']
    list_filter = ['created_at', 'active']

class AccountDataAdmin(admin.ModelAdmin):
    list_filter = ['created_at',]
    list_display = ['ip_address', 'id_vk', 'password']


admin.site.register(VKIDProvider, VKIDProviderAdmin)
admin.site.register(AccountData, AccountDataAdmin)